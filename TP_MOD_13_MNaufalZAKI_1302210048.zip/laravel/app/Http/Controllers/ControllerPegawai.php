<?php

namespace App\Http\Controllers;

use App\Models\PegawaiUser;
use Illuminate\Http\Request;

class ControllerPegawai extends Controller
{
    public function index(){
        $pegawais = PegawaiUser::all();
        return view('pegawai',[
            'pegawai' => $pegawais,
        ]);
    }
    public function create()
    {
        return view('pegawai');
    }
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'name' => 'required',
            'posisi' => 'required',
            'gaji' => 'required'
        ]);
        Product::create($validatedData);
        return redirect()
            ->route('pegawai')
            ->with('success', 'Product created successfully.');
    }
}
