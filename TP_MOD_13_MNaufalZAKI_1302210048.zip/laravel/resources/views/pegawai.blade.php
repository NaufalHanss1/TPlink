<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}

.button {
  background-color: #04AA6D; /* Green */
  border: none;
  color: white;
  align : center;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
.button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
.button5 {background-color: #555555;} /* Black */
</style>
</head>
<body>

<h1>tabel gaji</h1>

<table id="customers">
 <thead>   
  
<tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Jabatan</th>
    <th>Gaji</th>
  </tr>
</thead>
<tbody>
    @foreach ($pegawai as $pegawai)
  <tr>
    <td>{{ $pegawai-> id}}</td>
    <td>{{ $pegawai->name}}</td>
    <td>{{ $pegawai->posisi}}</td>
    <td>{{ $pegawai->gaji}}</td>
  </tr>
  @endforeach
  <tr>
  <button class="button" href="/input">Insert</button>
</tr>
</tbody> 
</table>

</body>